function hitung() {
    let harga = Number(document.getElementById("barang").value);
    let jumlah = Number(document.getElementById("jumlah").value);
    let member = document.getElementById("member").value;

    if (jumlah <= 0 || !Number.isInteger(jumlah)) {
        alert("Masukkan jumlah barang berupa angka bulat lebih dari 0!");
        return;
    }

    let total = harga * jumlah;
    let diskon = 0;

    if (member == "ya") {
        diskon = total * 10 / 100;
    }

    let bayar = total - diskon;

    document.getElementById("hasil").innerHTML =
        "Total Harga: Rp" + total.toLocaleString("id-ID") +
        "<br>Diskon: Rp" + diskon.toLocaleString("id-ID") +
        "<br><b>Total Bayar: Rp" + bayar.toLocaleString("id-ID") + "</b>";
}
