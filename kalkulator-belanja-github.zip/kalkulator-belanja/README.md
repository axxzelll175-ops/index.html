# Kalkulator Belanja Toko

Program kalkulator belanja sederhana menggunakan HTML dan JavaScript.

## Fitur
- Memilih barang dan harga.
- Memasukkan jumlah barang.
- Menghitung total harga.
- Diskon member sebesar 10%.
- Menampilkan total pembayaran.

## Cara Menjalankan
1. Buka file `index.html` di browser.
2. Pilih barang.
3. Masukkan jumlah barang.
4. Pilih status member.
5. Klik **Hitung Total**.

## File
- `index.html` — tampilan aplikasi.
- `script.js` — proses perhitungan.
